class MethodDemo
 {

   public static void main(String[] ar)
     {
        EvenCheck ch=new EvenCheck();
        boolean b=ch.isEven(34);
       System.out.println(b);
      }
  }