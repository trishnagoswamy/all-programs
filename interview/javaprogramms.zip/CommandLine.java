class CommandLine
{

 public static void main(String[] ar)
{
  System.out.println(ar[0]);  

      
}
}

 