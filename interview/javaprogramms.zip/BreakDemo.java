package mypack;

public class BreakDemo {
	public static void main(String[] ar)
	{
		for(int i=0;i<=100;i++)
		{
			if(i==10)
			{
              return;
			}
			System.out.println(i);

		}
		System.out.println("hai");
		
	}

}
