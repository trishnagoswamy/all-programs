class OperatorsDemo
{
  static public void main(String ar[])
   {
     int a=10;
      int b=20;
      System.out.println(a+"  "+b);
      System.out.println(-a);//-10
      System.out.println(a++);//10
      System.out.println(a+1);//12
      System.out.println(++a);//12
      System.out.println(a/2);//6
      System.out.println(a%2);//0

    }
 
}