class Sample
{
  public static void main(String ar[])
{
   int a=100;
    float f=102.234f;
    char ch='A';
     boolean b=true;
    String s="fgfgfdf";

    char[] str={'c','v','t'};
    System.out.println(a);
    System.out.println(f+" "+ch+"\t"+b+"\n"+s+"    "+str[1]);
     

  
}
 

 }