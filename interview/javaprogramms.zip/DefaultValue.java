class DefaultValue
 {
   int a;
float f;
  char ch;
boolean b;
 String s;
Sample s1;
  public static void main(String[] ar)
   {
 
     DefaultValue dv=new DefaultValue();
      System.out.println(dv.a+"\n"+dv.f+"\n"+dv.ch+"\n"+dv.b+"\n"+dv.s+"\n"+dv.s1);
 
   }
   
  }  