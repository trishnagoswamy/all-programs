package mypack.sample
;

public class Student {
	public String name;
	public int rollNo;

}
